import React from 'react';
import { Card } from 'antd';
import { Pie } from '@ant-design/plots';

const MarketDistribution = ({ data }) => {
  const config = {
    data,
    angleField: 'value',
    colorField: 'type',
    radius: 0.8,
    label: {
      type: 'outer',
      content: '{name} {percentage}',
    },
    interactions: [
      {
        type: 'element-active',
      },
    ],
    height: 300,
    theme: {
      colors10: ['#6b74e6', '#4CAF50', '#FF9800', '#E91E63', '#2196F3'],
    },
  };

  return (
    <Card className="stock-chart-card" title="Market Distribution">
      <Pie {...config} />
    </Card>
  );
};

export default MarketDistribution; 