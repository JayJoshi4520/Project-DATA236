import React from 'react';
import styled from 'styled-components';

const StockCardsContainer = styled.div`
  margin-top: 40px;
  margin-left: 40px;
  margin-right: 40px;
  padding: 20px 0;
  display: grid;
  grid-template-columns: repeat(4, 1fr);
  gap: 20px;
  width: calc(100% - 80px);
`;

const StockCard = styled.div`
  background: #1f1f1f;
  border: 1px solid #303030;
  border-radius: 8px;
  padding: 16px;
  
  .stock-name {
    color: #ffffff;
    font-size: 16px;
    margin-bottom: 12px;
  }
  
  .stock-info {
    display: flex;
    align-items: center;
    gap: 8px;
  }
  
  .stock-price {
    color: #ffffff;
    font-size: 24px;
    font-weight: bold;
  }
  
  .stock-change {
    display: flex;
    align-items: center;
    gap: 4px;
    font-size: 14px;
    &.up {
      color: #3f8600;
    }
    &.down {
      color: #cf1322;
    }
  }
`;

const StockCards = () => {
  const stockData = [
    { name: 'AAPL', price: 173.50, change: '+1.2', isUp: true },
    { name: 'GOOGL', price: 141.80, change: '-0.5', isUp: false },
    { name: 'MSFT', price: 378.85, change: '+2.1', isUp: true },
    { name: 'AMZN', price: 145.24, change: '+0.8', isUp: true }
  ];

  return (
    <StockCardsContainer>
      {stockData.map((stock) => (
        <StockCard key={stock.name}>
          <div className="stock-name">{stock.name}</div>
          <div className="stock-info">
            <span className="stock-price">${stock.price.toFixed(2)}</span>
            <span className={`stock-change ${stock.isUp ? 'up' : 'down'}`}>
              {stock.isUp ? '↑' : '↓'} {stock.change}%
            </span>
          </div>
        </StockCard>
      ))}
    </StockCardsContainer>
  );
};

export default StockCards; 