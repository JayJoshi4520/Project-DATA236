import React, { useState, useEffect } from 'react';
import { Row, Col, Card, Radio, Statistic } from 'antd';
import { Line } from 'react-chartjs-2';
import { ArrowUpOutlined, ArrowDownOutlined } from '@ant-design/icons';

const MarketOverview = () => {
  const [timeFrame, setTimeFrame] = useState('1D');
  const [chartData, setChartData] = useState({
    labels: [],
    datasets: []
  });

  // Define indices at the component level
  const indices = [
    {
      name: 'S&P 500',
      value: '4,550.23',
      suffix: 'pts',
      trend: 'up'
    },
    {
      name: 'NASDAQ',
      value: '14,200.45',
      suffix: 'pts',
      trend: 'up'
    },
    {
      name: 'DOW JONES',
      value: '35,100.65',
      suffix: 'pts',
      trend: 'down'
    }
  ];

  useEffect(() => {
    let labels = [];
    let s_and_p_data = [];
    let nasdaq_data = [];

    switch(timeFrame) {
      case '1D':
        // Generate labels for 24 days
        labels = Array.from({length: 24}, (_, i) => {
          const dayNum = i + 1;
          return dayNum === 1 ? '1 day' : `${dayNum} days`;  // "1 day", "2 days", etc.
        });
        
        // Generate random data points
        s_and_p_data = Array(labels.length).fill(4550).map(() => 
          Math.floor(Math.random() * (4600 - 4500) + 4500)
        );
        nasdaq_data = Array(labels.length).fill(14200).map(() => 
          Math.floor(Math.random() * (14300 - 14100) + 14100)
        );
        break;

      case '1W':
        // Generate labels for 1-7 for a week
        labels = Array.from({length: 7}, (_, i) => `${i + 1}`);
        s_and_p_data = Array(labels.length).fill(4550);
        nasdaq_data = Array(labels.length).fill(14200);
        break;

      case '1M':
        // Generate labels for each month
        labels = [
          'Jan', 'Feb', 'Mar', 'Apr', 'May', 'Jun',
          'Jul', 'Aug', 'Sep', 'Oct', 'Nov', 'Dec'
        ];
        s_and_p_data = Array(labels.length).fill(4550);
        nasdaq_data = Array(labels.length).fill(14200);
        break;

      case '1Y':
        // Generate labels for last 5 years
        const currentYear = new Date().getFullYear();
        labels = Array.from({length: 5}, (_, i) => `${currentYear - 4 + i}`);
        s_and_p_data = Array(labels.length).fill(4550);
        nasdaq_data = Array(labels.length).fill(14200);
        break;

      default:
        break;
    }

    setChartData({
      labels: labels,
      datasets: [
        {
          label: 'S&P 500',
          data: s_and_p_data,
          borderColor: '#6B74E6',
          tension: 0.4,
          pointRadius: 0,
        },
        {
          label: 'NASDAQ',
          data: nasdaq_data,
          borderColor: '#FF9800',
          tension: 0.4,
          pointRadius: 0,
        }
      ]
    });
  }, [timeFrame]);

  return (
    <div className="market-overview-container">
      {/* Market Indices Cards */}
      <Row gutter={[16, 16]} style={{ marginBottom: '20px' }}>
        {indices.map((index, i) => (
          <Col xs={24} md={8} key={i}>
            <Card 
              className="market-index-card"
              style={{ 
                background: 'rgba(255, 255, 255, 0.05)',
                border: '1px solid #303030',
                borderRadius: '12px'
              }}
            >
              <Statistic
                title={<span style={{ color: '#808A9D' }}>{index.name}</span>}
                value={index.value}
                suffix={index.suffix}
                prefix={index.trend === 'up' ? 
                  <ArrowUpOutlined style={{ color: '#4CAF50' }} /> : 
                  <ArrowDownOutlined style={{ color: '#f44336' }} />
                }
                valueStyle={{ 
                  color: 'white',
                  fontSize: '24px',
                  fontWeight: 'bold'
                }}
              />
            </Card>
          </Col>
        ))}
      </Row>

      {/* Market Indices Chart */}
      <Card 
        title={<h2 style={{ color: 'white', margin: 0 }}>Market Indices</h2>}
        className="market-chart-card"
      >
        <div style={{ marginBottom: 20 }}>
          <Radio.Group 
            value={timeFrame}
            onChange={e => setTimeFrame(e.target.value)}
            className="time-frame-selector"
          >
            <Radio.Button value="1D">1D</Radio.Button>
            <Radio.Button value="1W">1W</Radio.Button>
            <Radio.Button value="1M">1M</Radio.Button>
            <Radio.Button value="1Y">1Y</Radio.Button>
          </Radio.Group>
        </div>
        <div style={{ height: '400px' }}>
          <Line 
            data={chartData} 
            options={{
              responsive: true,
              maintainAspectRatio: false,
              plugins: {
                legend: {
                  position: 'top',
                  align: 'start',
                  labels: { 
                    color: 'white',
                    boxWidth: 15,
                    usePointStyle: true,
                    pointStyle: 'line'
                  }
                }
              },
              scales: {
                y: {
                  position: 'right',
                  ticks: { 
                    color: 'white',
                    callback: function(value) {
                      return value.toLocaleString();
                    }
                  },
                  grid: { 
                    color: 'rgba(255, 255, 255, 0.1)',
                    drawBorder: false
                  }
                },
                x: {
                  ticks: { 
                    color: 'white',
                    maxRotation: 0,
                    minRotation: 0,
                    autoSkip: false,
                    callback: function(value, index) {
                      // Return the actual label instead of the index
                      return this.chart.data.labels[index];
                    }
                  },
                  grid: { 
                    display: true,
                    color: 'rgba(255, 255, 255, 0.1)',
                    drawBorder: false
                  }
                }
              }
            }} 
          />
        </div>
      </Card>
    </div>
  );
};

export default MarketOverview; 