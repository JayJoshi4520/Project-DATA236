import React from 'react';
import styled from 'styled-components';
import { Pie } from 'react-chartjs-2';
import '../utils/chartConfig';

const ChartContainer = styled.div`
  background: #1F1F1F;
  border-radius: 12px;
  padding: 24px;
  height: 300px;
`;

export const PieChart = () => {
  const data = {
    labels: ['AAPL', 'GOOGL', 'MSFT', 'AMZN'],
    datasets: [
      {
        data: [30, 25, 25, 20],
        backgroundColor: [
          'rgba(75, 192, 192, 0.8)',
          'rgba(255, 99, 132, 0.8)',
          'rgba(54, 162, 235, 0.8)',
          'rgba(255, 206, 86, 0.8)',
        ],
        borderColor: [
          'rgba(75, 192, 192, 1)',
          'rgba(255, 99, 132, 1)',
          'rgba(54, 162, 235, 1)',
          'rgba(255, 206, 86, 1)',
        ],
        borderWidth: 1,
      },
    ],
  };

  const options = {
    responsive: true,
    maintainAspectRatio: false,
    plugins: {
      legend: {
        position: 'right',
        labels: {
          color: '#FFFFFF'
        }
      },
      title: {
        display: true,
        text: 'Portfolio Distribution',
        color: '#FFFFFF'
      }
    }
  };

  return (
    <ChartContainer>
      <Pie data={data} options={options} />
    </ChartContainer>
  );
};

export default PieChart; 