import axios from 'axios';

const instance = axios.create({
  baseURL: 'http://127.0.0.1:8000/getlivedata',
});

export const fetchStockData = async (symbol, timeFrame) => {
  try {
    const response = await instance.get(`/stock/${symbol}`, {
      params: {
        timeFrame: timeFrame
      }
    });
    return response.data;
  } catch (error) {
    console.error('Error fetching stock data:', error);
    throw error;
  }
};

export default instance; 