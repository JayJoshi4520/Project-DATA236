import React, { useState, useEffect } from 'react';
import { Row, Col, Card, Radio, Input } from 'antd';
import { Line } from 'react-chartjs-2';

const { Search } = Input;

const StockAnalysis = () => {
  const [timeFrame, setTimeFrame] = useState('1D');
  const [chartData, setChartData] = useState({
    labels: [],
    datasets: [{
      label: 'Stock Price',
      data: [],
      borderColor: '#6B74E6',
      tension: 0.1,
    }]
  });

  // Company Information
  const companyInfo = {
    name: 'Meta Platforms Inc',
    ipoDate: '2012-05-18',
    country: 'US',
    marketCap: '923.27B',
    currency: 'USD',
    industry: 'Media',
    exchange: 'NASDAQ NMS - GLOBAL MARKET'
  };

  useEffect(() => {
    let labels = [];
    const data = Array.from({ length: 24 }, () => 
      Math.floor(Math.random() * (330 - 320) + 320)
    );

    switch(timeFrame) {
      case '1D':
        // Generate labels for 24 days
        labels = Array.from({length: 24}, (_, i) => {
          const dayNum = i + 1;
          return dayNum === 1 ? '1 day' : `${dayNum} days`;
        });
        break;
      case '1W':
        labels = Array.from({length: 7}, (_, i) => `${i + 1}`);
        break;
      case '1M':
        labels = ['Jan', 'Feb', 'Mar', 'Apr', 'May', 'Jun', 
                 'Jul', 'Aug', 'Sep', 'Oct', 'Nov', 'Dec'];
        break;
      case '1Y':
        const currentYear = new Date().getFullYear();
        labels = Array.from({ length: 5 }, (_, i) => 
          `${currentYear - 4 + i}`
        );
        break;
      default:
        labels = [];
    }

    setChartData({
      labels: labels,
      datasets: [{
        label: 'Stock Price',
        data: data.slice(0, labels.length),
        borderColor: '#6B74E6',
        tension: 0.4,
        pointRadius: 0,
      }]
    });
  }, [timeFrame]);

  return (
    <div className="stock-analysis-container">
      {/* Company Information Card */}
      <Card 
        className="company-info-card"
        style={{ 
          background: '#1A1A1A',
          border: '1px solid #303030',
          borderRadius: '12px',
          marginBottom: '20px'
        }}
      >
        <Row gutter={[32, 16]}>
          <Col xs={24} md={12}>
            <div className="info-group">
              <div className="info-item">
                <span className="label">Name</span>
                <span className="value">{companyInfo.name}</span>
              </div>
              <div className="info-item">
                <span className="label">Country</span>
                <span className="value">{companyInfo.country}</span>
              </div>
              <div className="info-item">
                <span className="label">Currency</span>
                <span className="value">{companyInfo.currency}</span>
              </div>
              <div className="info-item">
                <span className="label">Exchange</span>
                <span className="value">{companyInfo.exchange}</span>
              </div>
            </div>
          </Col>
          <Col xs={24} md={12}>
            <div className="info-group">
              <div className="info-item">
                <span className="label">IPO Date</span>
                <span className="value">{companyInfo.ipoDate}</span>
              </div>
              <div className="info-item">
                <span className="label">Market Capitalization</span>
                <span className="value">{companyInfo.marketCap}</span>
              </div>
              <div className="info-item">
                <span className="label">Industry</span>
                <span className="value">{companyInfo.industry}</span>
              </div>
            </div>
          </Col>
        </Row>
      </Card>

      {/* Chart Card */}
      <Card 
        className="stock-chart-card"
        style={{ 
          background: '#1A1A1A',
          border: '1px solid #303030',
          borderRadius: '12px'
        }}
      >
        <div style={{ marginBottom: 20 }}>
          <Search
            placeholder="Search stock..."
            style={{ maxWidth: 300, marginBottom: 20 }}
          />
          <Radio.Group 
            value={timeFrame}
            onChange={e => setTimeFrame(e.target.value)}
            className="time-frame-selector"
          >
            <Radio.Button value="1D">1D</Radio.Button>
            <Radio.Button value="1W">1W</Radio.Button>
            <Radio.Button value="1M">1M</Radio.Button>
            <Radio.Button value="1Y">1Y</Radio.Button>
          </Radio.Group>
        </div>
        <div style={{ height: '400px' }}>
          <Line 
            data={chartData} 
            options={{
              responsive: true,
              maintainAspectRatio: false,
              plugins: {
                legend: {
                  display: false
                }
              },
              scales: {
                y: {
                  position: 'right',
                  ticks: { 
                    color: 'white',
                    callback: function(value) {
                      return value.toLocaleString();
                    }
                  },
                  grid: { 
                    color: 'rgba(255, 255, 255, 0.1)',
                    drawBorder: false
                  }
                },
                x: {
                  ticks: { 
                    color: 'white',
                    maxRotation: 0,
                    minRotation: 0,
                    autoSkip: false,
                    callback: function(value, index) {
                      return this.chart.data.labels[index];
                    }
                  },
                  grid: { 
                    color: 'rgba(255, 255, 255, 0.1)',
                    drawBorder: false
                  }
                }
              }
            }} 
          />
        </div>
      </Card>
    </div>
  );
};

export default StockAnalysis; 