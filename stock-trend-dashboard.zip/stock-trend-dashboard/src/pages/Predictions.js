import React, { useState, useEffect } from 'react';
import { Row, Col, Card, Radio, Table } from 'antd';
import { Line } from 'react-chartjs-2';
import { generateDataForTimeFrame } from '../utils/chartDataHelper';

const Predictions = () => {
  const [timeFrame, setTimeFrame] = useState('1D');
  const [predictionData, setPredictionData] = useState(null);

  // Prediction summary data
  const columns = [
    {
      title: 'Stock',
      dataIndex: 'stock',
      key: 'stock',
      render: text => <span style={{ color: 'white' }}>{text}</span>
    },
    {
      title: 'Current Price',
      dataIndex: 'currentPrice',
      key: 'currentPrice',
      render: text => <span style={{ color: 'white' }}>${text}</span>
    },
    {
      title: 'Predicted Price',
      dataIndex: 'predictedPrice',
      key: 'predictedPrice',
      render: text => <span style={{ color: 'white' }}>${text}</span>
    },
    {
      title: 'Recommendation',
      dataIndex: 'recommendation',
      key: 'recommendation',
      render: text => {
        let color = '';
        switch(text.toLowerCase()) {
          case 'buy':
            color = '#4CAF50';
            break;
          case 'hold':
            color = '#FFA726';
            break;
          case 'sell':
            color = '#f44336';
            break;
          default:
            color = 'white';
        }
        return <span style={{ 
          color: 'white', 
          backgroundColor: color,
          padding: '4px 12px',
          borderRadius: '4px',
          textTransform: 'capitalize'
        }}>{text}</span>
      }
    },
  ];

  const data = [
    {
      key: '1',
      stock: 'AAPL',
      currentPrice: '150.23',
      predictedPrice: '165.45',
      recommendation: 'Buy',
    },
    {
      key: '2',
      stock: 'GOOGL',
      currentPrice: '134.99',
      predictedPrice: '142.30',
      recommendation: 'Hold',
    },
    {
      key: '3',
      stock: 'MSFT',
      currentPrice: '323.12',
      predictedPrice: '318.90',
      recommendation: 'Sell',
    },
  ];

  useEffect(() => {
    const { labels, data } = generateDataForTimeFrame(timeFrame);
    const predictedValues = data.map(val => val * 1.1);
    
    setPredictionData({
      labels: labels,
      datasets: [
        {
          label: 'Actual',
          data: data,
          borderColor: '#6B74E6',
          tension: 0.1,
        },
        {
          label: 'Predicted',
          data: predictedValues,
          borderColor: '#4CAF50',
          borderDash: [5, 5],
          tension: 0.1,
        }
      ]
    });
  }, [timeFrame]);

  const chartOptions = {
    responsive: true,
    maintainAspectRatio: false,
    plugins: {
      legend: {
        position: 'top',
        labels: { color: 'white' }
      }
    },
    scales: {
      y: {
        ticks: { color: 'white' },
        grid: { color: 'rgba(255, 255, 255, 0.1)' }
      },
      x: {
        ticks: { 
          color: 'white',
          maxRotation: 45,
          minRotation: 45
        },
        grid: { color: 'rgba(255, 255, 255, 0.1)' }
      }
    }
  };

  return (
    <div className="predictions-container">
      {/* Prediction Summary Table */}
      <Card 
        title={<h2 style={{ color: 'white', margin: 0 }}>Prediction Summary</h2>}
        className="prediction-summary-card"
        style={{ marginBottom: '20px', background: '#1A1A1A', border: '1px solid #303030' }}
      >
        <Table 
          columns={columns} 
          dataSource={data} 
          pagination={{ 
            current: 1,
            pageSize: 5,
            total: data.length,
            className: 'custom-pagination'
          }}
          style={{ 
            background: '#1A1A1A',
            color: 'white'
          }}
        />
      </Card>

      {/* Prediction Chart */}
      <Card 
        className="prediction-chart-card"
        style={{ background: '#1A1A1A', border: '1px solid #303030' }}
      >
        <div style={{ marginBottom: 20 }}>
          <Radio.Group 
            value={timeFrame}
            onChange={e => setTimeFrame(e.target.value)}
            className="time-frame-selector"
          >
            <Radio.Button value="1D">1D</Radio.Button>
            <Radio.Button value="1W">1W</Radio.Button>
            <Radio.Button value="1M">1M</Radio.Button>
            <Radio.Button value="1Y">1Y</Radio.Button>
          </Radio.Group>
        </div>
        <div style={{ height: '400px' }}>
          {predictionData && <Line data={predictionData} options={chartOptions} />}
        </div>
      </Card>
    </div>
  );
};

export default Predictions; 