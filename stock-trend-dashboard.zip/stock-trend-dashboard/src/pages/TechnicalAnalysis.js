import React, { useState, useEffect } from 'react';
import { Row, Col, Card, Radio, Statistic } from 'antd';
import { Line } from 'react-chartjs-2';

const TechnicalAnalysis = () => {
  const [timeFrame, setTimeFrame] = useState('1D');
  const [chartData, setChartData] = useState({
    labels: [],
    datasets: [
      {
        label: 'Moving Average (MA)',
        data: [],
        borderColor: '#6B74E6',
        tension: 0.1,
      },
      {
        label: 'Bollinger Bands (Upper)',
        data: [],
        borderColor: '#4CAF50',
        tension: 0.1,
      },
      {
        label: 'Bollinger Bands (Lower)',
        data: [],
        borderColor: '#f44336',
        tension: 0.1,
      }
    ]
  });

  // Technical Indicators Data
  const indicators = [
    {
      title: 'Moving Average (20)',
      value: '175.43',
      suffix: '$',
    },
    {
      title: 'RSI (14)',
      value: '65.32',
      suffix: '%',
    },
    {
      title: 'Bollinger Band Width',
      value: '2.45',
      suffix: '%',
    },
  ];

  useEffect(() => {
    let labels = [];
    const baseData = Array.from({ length: 24 }, () => 
      Math.floor(Math.random() * (330 - 320) + 320)
    );

    // Generate labels based on timeFrame
    switch(timeFrame) {
      case '1D':
        // For 1D: Show "1 day" to "24 day"
        labels = Array.from({ length: 24 }, (_, i) => 
          `${i + 1} day`
        );
        break;
      case '1W':
        // For 1W: Show "1" to "7"
        labels = Array.from({ length: 7 }, (_, i) => 
          `${i + 1}`
        );
        break;
      case '1M':
        // For 1M: Show month names
        labels = ['Jan', 'Feb', 'Mar', 'Apr', 'May', 'Jun', 
                 'Jul', 'Aug', 'Sep', 'Oct', 'Nov', 'Dec'];
        break;
      case '1Y':
        // For 1Y: Show years
        const currentYear = new Date().getFullYear();
        labels = Array.from({ length: 5 }, (_, i) => 
          `${currentYear - 4 + i}`
        );
        break;
      default:
        labels = [];
    }

    const dataLength = labels.length;
    const data = baseData.slice(0, dataLength);

    setChartData({
      labels: labels,
      datasets: [
        {
          label: 'Moving Average (MA)',
          data: data,
          borderColor: '#6B74E6',
          tension: 0.1,
        },
        {
          label: 'Bollinger Bands (Upper)',
          data: data.map(val => val + 5),
          borderColor: '#4CAF50',
          tension: 0.1,
        },
        {
          label: 'Bollinger Bands (Lower)',
          data: data.map(val => val - 5),
          borderColor: '#f44336',
          tension: 0.1,
        }
      ]
    });
  }, [timeFrame]);

  return (
    <div className="technical-analysis-container">
      {/* Technical Indicators Cards */}
      <Row gutter={[16, 16]} style={{ marginBottom: '20px' }}>
        {indicators.map((indicator, index) => (
          <Col xs={24} sm={8} key={index}>
            <Card 
              className="indicator-card"
              style={{ 
                background: 'rgba(255, 255, 255, 0.05)',
                border: '1px solid #303030',
                borderRadius: '12px'
              }}
            >
              <Statistic
                title={<span style={{ color: '#808A9D' }}>{indicator.title}</span>}
                value={indicator.value}
                suffix={indicator.suffix}
                valueStyle={{ 
                  color: 'white',
                  fontSize: '24px',
                  fontWeight: 'bold'
                }}
              />
            </Card>
          </Col>
        ))}
      </Row>

      {/* Chart Card */}
      <Card 
        className="chart-card"
        style={{ 
          background: '#1A1A1A',
          border: '1px solid #303030',
          borderRadius: '12px'
        }}
      >
        <div style={{ marginBottom: 20 }}>
          <Radio.Group 
            value={timeFrame}
            onChange={e => setTimeFrame(e.target.value)}
            className="time-frame-selector"
          >
            <Radio.Button value="1D">1D</Radio.Button>
            <Radio.Button value="1W">1W</Radio.Button>
            <Radio.Button value="1M">1M</Radio.Button>
            <Radio.Button value="1Y">1Y</Radio.Button>
          </Radio.Group>
        </div>
        <div style={{ height: '400px' }}>
          <Line 
            data={chartData} 
            options={{
              responsive: true,
              maintainAspectRatio: false,
              plugins: {
                legend: {
                  position: 'top',
                  labels: { color: 'white' }
                }
              },
              scales: {
                y: {
                  ticks: { color: 'white' },
                  grid: { color: 'rgba(255, 255, 255, 0.1)' }
                },
                x: {
                  ticks: { 
                    color: 'white',
                    maxRotation: 45,
                    minRotation: 45
                  },
                  grid: { color: 'rgba(255, 255, 255, 0.1)' }
                }
              }
            }} 
          />
        </div>
      </Card>
    </div>
  );
};

export default TechnicalAnalysis; 