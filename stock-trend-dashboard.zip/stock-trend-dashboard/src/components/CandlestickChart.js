import React, { useState } from 'react';
import styled from 'styled-components';
import ReactApexChart from 'react-apexcharts';

const ChartContainer = styled.div`
  background: #1F1F1F;
  border-radius: 12px;
  padding: 24px;
  height: 400px;
`;

const TimeFrameSelector = styled.div`
  display: flex;
  gap: 12px;
  margin-bottom: 16px;
`;

const TimeFrameButton = styled.button`
  background: ${props => props.active ? '#4CAF50' : '#2D2D2D'};
  color: ${props => props.active ? '#FFFFFF' : '#A0A0A0'};
  border: none;
  border-radius: 6px;
  padding: 8px 16px;
  cursor: pointer;
  transition: all 0.3s ease;

  &:hover {
    background: ${props => props.active ? '#4CAF50' : '#3D3D3D'};
  }
`;

const CandlestickChart = () => {
  const [timeFrame, setTimeFrame] = useState('1M');

  const getChartData = () => {
    switch(timeFrame) {
      case '1D':
        return [
          { x: 'Day 1', y: [60.10, 62.30, 59.80, 61.50] },
          { x: 'Day 2', y: [61.50, 63.20, 61.00, 62.80] },
          { x: 'Day 3', y: [62.80, 64.50, 62.00, 64.00] },
          { x: 'Day 4', y: [64.00, 65.00, 63.50, 64.80] },
          { x: 'Day 5', y: [64.80, 65.20, 64.00, 64.50] },
          { x: 'Day 6', y: [64.50, 65.00, 63.00, 63.20] },
          { x: 'Day 7', y: [63.20, 64.00, 62.50, 63.50] }
        ];
      case '1W':
        return [
          { x: 'Week 1', y: [61.50, 65.20, 61.00, 64.80] },
          { x: 'Week 2', y: [64.80, 68.50, 64.00, 68.00] },
          { x: 'Week 3', y: [68.00, 70.00, 67.50, 69.80] },
          { x: 'Week 4', y: [69.80, 71.20, 68.00, 68.50] }
        ];
      case '1M':
        return [
          { x: 'Jan', y: [60.10, 62.30, 59.80, 61.50] },
          { x: 'Feb', y: [61.50, 65.20, 61.00, 64.80] },
          { x: 'Mar', y: [64.80, 70.50, 64.00, 70.00] },
          { x: 'Apr', y: [70.00, 75.00, 69.50, 74.80] },
          { x: 'May', y: [74.80, 75.20, 70.00, 70.50] },
          { x: 'Jun', y: [70.50, 71.00, 65.00, 65.20] }
        ];
      case '1Y':
        return [
          { x: '2020', y: [60.10, 65.30, 58.80, 64.50] },
          { x: '2021', y: [64.50, 70.20, 63.00, 69.80] },
          { x: '2022', y: [69.80, 75.50, 68.00, 73.00] },
          { x: '2023', y: [73.00, 78.00, 71.50, 72.80] },
          { x: '2024', y: [72.80, 75.20, 70.00, 71.50] }
        ];
      default:
        return [];
    }
  };

  const options = {
    chart: {
      type: 'candlestick',
      height: 350,
      background: '#1F1F1F',
      foreColor: '#A0A0A0'
    },
    title: {
      text: 'Stock Price Movement (OHLC)',
      align: 'left',
      style: {
        color: '#FFFFFF'
      }
    },
    xaxis: {
      type: 'category',
      labels: {
        style: {
          colors: '#A0A0A0'
        }
      },
      axisBorder: {
        color: '#404040'
      },
      axisTicks: {
        color: '#404040'
      }
    },
    yaxis: {
      tooltip: {
        enabled: true
      },
      labels: {
        style: {
          colors: '#A0A0A0'
        },
        formatter: (value) => `$${value.toFixed(2)}`
      }
    },
    grid: {
      borderColor: '#404040',
      xaxis: {
        lines: {
          show: true
        }
      },
      yaxis: {
        lines: {
          show: true
        }
      }
    },
    plotOptions: {
      candlestick: {
        colors: {
          upward: '#4CAF50',
          downward: '#FF5252'
        },
        wick: {
          useFillColor: true
        }
      }
    },
    tooltip: {
      theme: 'dark',
      y: {
        formatter: (value) => `$${value.toFixed(2)}`
      }
    }
  };

  return (
    <ChartContainer>
      <TimeFrameSelector>
        <TimeFrameButton 
          active={timeFrame === '1D'} 
          onClick={() => setTimeFrame('1D')}
        >
          1D
        </TimeFrameButton>
        <TimeFrameButton 
          active={timeFrame === '1W'} 
          onClick={() => setTimeFrame('1W')}
        >
          1W
        </TimeFrameButton>
        <TimeFrameButton 
          active={timeFrame === '1M'} 
          onClick={() => setTimeFrame('1M')}
        >
          1M
        </TimeFrameButton>
        <TimeFrameButton 
          active={timeFrame === '1Y'} 
          onClick={() => setTimeFrame('1Y')}
        >
          1Y
        </TimeFrameButton>
      </TimeFrameSelector>
      <ReactApexChart 
        options={options}
        series={[{ data: getChartData() }]}
        type="candlestick"
        height="100%"
      />
    </ChartContainer>
  );
};

export default CandlestickChart; 