import React from 'react';
import styled from 'styled-components';
import Marquee from "react-fast-marquee";
import StockCards from '../components/StockCards';
import StockChart from '../components/StockChart';
import PieChart from '../components/PieChart';
import CandlestickChart from '../components/CandlestickChart';
import '../utils/chartConfig';

const SIDEBAR_WIDTH = 280;

const DashboardTitle = styled.h1`
  color: #ffffff;
  font-size: 24px;
  text-align: center;
  margin: 0;
  padding: 16px 0;
  position: fixed;
  top: 20px;
  left: ${SIDEBAR_WIDTH}px;
  right: 40px;
  background: #1A1A1A;
  z-index: 1000;
`;

const MarqueeContainer = styled.div`
  background: transparent;
  padding: 8px 0;
  overflow: hidden;
  position: fixed;
  top: 70px;
  left: ${SIDEBAR_WIDTH}px;
  right: 40px;
  z-index: 999;
  border-top: 1px solid #303030;
  border-bottom: 1px solid #303030;
`;

const MarqueeItem = styled.span`
  display: inline-flex;
  align-items: center;
  margin: 0 24px;
  color: #ffffff;
  font-size: 16px;
  white-space: nowrap;

  .stock-change {
    margin-left: 12px;
    &.up {
      color: #4CAF50;
    }
    &.down {
      color: #F44336;
    }
  }
`;

const DashboardContainer = styled.div`
  padding: 0;
  margin-top: 140px;
  margin-left: 0;
  margin-right: 0;
  display: flex;
  flex-direction: column;
  width: 100%;
  height: calc(100vh - 140px);
  position: relative;
  overflow-y: auto;
  overflow-x: hidden;
  background: #1A1A1A;
`;

const ChartsGrid = styled.div`
  display: grid;
  grid-template-columns: 1fr 1fr;  // Two columns
  grid-template-rows: auto auto;    // Two rows
  gap: 24px;
  padding: 20px 40px;
  width: calc(100% - 80px);        // Account for padding
  margin-top: 20px;

  @media (max-width: 1024px) {
    grid-template-columns: 1fr;     // Stack on mobile
  }
`;

const ChartWrapper = styled.div`
  width: 100%;
  height: 100%;
  min-height: 300px;
  background: #1F1F1F;
  border-radius: 12px;
  padding: 20px;
  box-sizing: border-box;
`;

const Dashboard = () => {
  const stockData = [
    { name: 'AAPL', price: 173.50, change: 1.2, isUp: true },
    { name: 'GOOGL', price: 141.80, change: -0.5, isUp: false },
    { name: 'MSFT', price: 378.85, change: 2.1, isUp: true },
    { name: 'AMZN', price: 145.24, change: 0.8, isUp: true }
  ];

  return (
    <>
      <DashboardTitle>Stock Market Prediction</DashboardTitle>
      
      <MarqueeContainer>
        <Marquee gradient={false} speed={40}>
          {stockData.map((stock) => (
            <MarqueeItem key={stock.name}>
              {stock.name} ${stock.price.toFixed(2)}
              <span className={`stock-change ${stock.isUp ? 'up' : 'down'}`}>
                {stock.isUp ? '↑' : '↓'} {stock.change}%
              </span>
            </MarqueeItem>
          ))}
        </Marquee>
      </MarqueeContainer>

      <DashboardContainer>
        <StockCards />
        <ChartsGrid>
          <ChartWrapper>
            <StockChart />
          </ChartWrapper>
          <ChartWrapper>
            <PieChart />
          </ChartWrapper>
          <ChartWrapper style={{ gridColumn: '1 / -1' }}>  {/* Make candlestick chart full width */}
            <CandlestickChart />
          </ChartWrapper>
        </ChartsGrid>
      </DashboardContainer>
    </>
  );
};

export default Dashboard;