import React, { useState } from 'react';
import styled from 'styled-components';
import { Line } from 'react-chartjs-2';

const ChartContainer = styled.div`
  background: #1F1F1F;
  border-radius: 12px;
  padding: 24px;
  height: 300px;
`;

const TimeFrameSelector = styled.div`
  display: flex;
  gap: 12px;
  margin-bottom: 16px;
`;

const TimeFrameButton = styled.button`
  background: ${props => props.active ? '#4CAF50' : '#2D2D2D'};
  color: ${props => props.active ? '#FFFFFF' : '#A0A0A0'};
  border: none;
  border-radius: 6px;
  padding: 8px 16px;
  cursor: pointer;
  transition: all 0.3s ease;

  &:hover {
    background: ${props => props.active ? '#4CAF50' : '#3D3D3D'};
  }
`;

const StockChart = () => {
  const [timeFrame, setTimeFrame] = useState('1M');

  const getChartData = () => {
    switch(timeFrame) {
      case '1D':
        return {
          labels: ['Day 1', 'Day 2', 'Day 3', 'Day 4', 'Day 5', 'Day 6', 'Day 7'],
          data: [65, 62, 64, 63, 66, 68, 65]
        };
      case '1W':
        return {
          labels: ['Week 1', 'Week 2', 'Week 3', 'Week 4'],
          data: [64, 63, 65, 67]
        };
      case '1M':
        return {
          labels: ['Jan', 'Feb', 'Mar', 'Apr', 'May', 'Jun'],
          data: [65, 60, 80, 81, 56, 55]
        };
      case '1Y':
        return {
          labels: ['2020', '2021', '2022', '2023', '2024'],
          data: [65, 70, 75, 72, 68]
        };
      default:
        return {
          labels: ['Jan', 'Feb', 'Mar', 'Apr', 'May', 'Jun'],
          data: [65, 59, 80, 81, 56, 55]
        };
    }
  };

  const chartData = {
    labels: getChartData().labels,
    datasets: [
      {
        label: 'Stock Price',
        data: getChartData().data,
        borderColor: '#4CAF50',
        backgroundColor: 'rgba(76, 175, 80, 0.1)',
        fill: true,
        tension: 0.4
      }
    ]
  };

  const options = {
    responsive: true,
    maintainAspectRatio: false,
    plugins: {
      legend: {
        display: false
      },
      title: {
        display: true,
        text: 'Stock Price Movement',
        color: '#FFFFFF',
        font: {
          size: 16
        }
      }
    },
    scales: {
      y: {
        grid: {
          color: 'rgba(255, 255, 255, 0.1)'
        },
        ticks: {
          color: '#A0A0A0',
          callback: (value) => `$${value}`
        }
      },
      x: {
        grid: {
          color: 'rgba(255, 255, 255, 0.1)'
        },
        ticks: {
          color: '#A0A0A0'
        }
      }
    }
  };

  return (
    <ChartContainer>
      <TimeFrameSelector>
        <TimeFrameButton 
          active={timeFrame === '1D'} 
          onClick={() => setTimeFrame('1D')}
        >
          1D
        </TimeFrameButton>
        <TimeFrameButton 
          active={timeFrame === '1W'} 
          onClick={() => setTimeFrame('1W')}
        >
          1W
        </TimeFrameButton>
        <TimeFrameButton 
          active={timeFrame === '1M'} 
          onClick={() => setTimeFrame('1M')}
        >
          1M
        </TimeFrameButton>
        <TimeFrameButton 
          active={timeFrame === '1Y'} 
          onClick={() => setTimeFrame('1Y')}
        >
          1Y
        </TimeFrameButton>
      </TimeFrameSelector>
      <Line data={chartData} options={options} />
    </ChartContainer>
  );
};

export default StockChart;